# -*- coding: utf-8 -*-
"""
Created on Sun Aug  1 10:26:58 2021

@author: Tommy
"""

def Cat(n):
    if n == 0: return 1
    else:
        su = 0
        for j in range(n): 
            su += Cat(j)*Cat(n-1-j)
        return su

# main program
print(); print('Catalan Numbers')
n = int(input('limit = '))

for i in range(n+1):
    print('C(',i,') = ',round(Cat(i)))
