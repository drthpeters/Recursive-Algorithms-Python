# -*- coding: utf-8 -*-
"""
Created on Mon Jul  5 15:31:23 2021

@author: Tommy
"""

namesList = []; newList = []
with open('names.txt') as f:
    lines = f.readlines()

newList = []
with open('newNames.txt') as fn:
    newlines = fn.readlines()

for i in range(len(lines)):
    namesList.append(lines[i][:-1]) 
    
#for j in range(len(newlines)):
#    newList.append(lines_sort[i][:-1]) 
    
namesSort = sorted(namesList)    

with open('names_sort.txt', 'w') as f:
    for name in namesSort:
        f.write(name + '\n')